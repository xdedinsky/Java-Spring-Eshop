package sk.stuba.fei.uim.oop.assignment3.cart.data;

import javax.persistence.Entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import sk.stuba.fei.uim.oop.assignment3.product.data.Product;

@Entity
@Data
@NoArgsConstructor
public class ShoppingProduct {
    @Id
    private Long Id;
    private long amount;
    @ManyToOne
    private Product product;

    public ShoppingProduct(Product product, Long amount) {
        this.Id = product.getId();
        this.amount = amount;
        this.product = product;
    }
}
