package sk.stuba.fei.uim.oop.assignment3.product.logic;

import org.springframework.stereotype.Repository;
import sk.stuba.fei.uim.oop.assignment3.exception.NotFoundException;
import sk.stuba.fei.uim.oop.assignment3.product.data.Product;
import sk.stuba.fei.uim.oop.assignment3.product.web.bodies.ProductRequest;

import java.util.List;

@Repository
public interface IProductService {
    List<Product> getAll();
    Product create(ProductRequest request);
    Product findById(long id) throws NotFoundException;
    Product update(long id, ProductRequest request) throws NotFoundException;
    void delete(long id) throws NotFoundException;
    long getAmount(long id) throws NotFoundException;
    long addAmount(long id, long increment) throws NotFoundException;
}
