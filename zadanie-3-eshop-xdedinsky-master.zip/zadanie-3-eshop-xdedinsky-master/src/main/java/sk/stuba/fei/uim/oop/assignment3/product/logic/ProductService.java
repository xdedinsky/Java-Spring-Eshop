package sk.stuba.fei.uim.oop.assignment3.product.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.uim.oop.assignment3.exception.NotFoundException;
import sk.stuba.fei.uim.oop.assignment3.product.data.IProductRepository;
import sk.stuba.fei.uim.oop.assignment3.product.data.Product;
import sk.stuba.fei.uim.oop.assignment3.product.web.bodies.ProductRequest;

import java.util.List;

@Service
public class ProductService implements IProductService {
    @Autowired
    private IProductRepository repository;

    @Override
    public List<Product> getAll(){
        return this.repository.findAll();
    }

    @Override
    public Product create(ProductRequest request){
        Product product = new Product(request);
        this.repository.save(product);
        return product;
    }

    @Override
    public Product findById(long id) throws NotFoundException{
        Product product = this.repository.findProductById(id);
        if (product == null) {
            throw new NotFoundException();
        }
        return product;
    }

    @Override
    public Product update(long id, ProductRequest request) throws NotFoundException{
        Product product = this.findById(id);
        product.setName(request.getName() != null ? request.getName() : product.getName());
        product.setDescription(request.getDescription() != null ? request.getDescription() : product.getDescription());
        this.repository.save(product);
        return product;
    }

    @Override
    public void delete(long id) throws NotFoundException{
        this.repository.delete(this.findById(id));
    }

    @Override
    public long getAmount(long id) throws NotFoundException{
        return this.findById(id).getAmount();
    }

    @Override
    public long addAmount(long id, long increment) throws NotFoundException{
        Product product = this.findById(id);
        product.setAmount(product.getAmount() + increment);
        this.repository.save(product);
        return product.getAmount();
    }
}
