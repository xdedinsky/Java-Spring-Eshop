package sk.stuba.fei.uim.oop.assignment3.cart.data;

import javax.persistence.Entity;

import lombok.Data;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToMany
    private List<ShoppingProduct> shoppingProductList;
    private boolean payed;

    public Cart() {
        this.shoppingProductList = new ArrayList<>();
        this.payed = false;
    }
}
