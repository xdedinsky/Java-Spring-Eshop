package sk.stuba.fei.uim.oop.assignment3.exception;

public class NotFoundException extends Exception {
}
