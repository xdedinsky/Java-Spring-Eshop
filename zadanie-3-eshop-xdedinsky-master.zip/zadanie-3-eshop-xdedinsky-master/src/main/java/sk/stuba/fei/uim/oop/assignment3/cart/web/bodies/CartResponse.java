package sk.stuba.fei.uim.oop.assignment3.cart.web.bodies;

import lombok.Getter;
import sk.stuba.fei.uim.oop.assignment3.cart.data.Cart;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public class CartResponse {
    private final Long id;
    private final List<ShoppingProductResponse> shoppingList;
    private final boolean payed;

    public CartResponse(Cart cart) {
        this.id = cart.getId();
        this.shoppingList = new ArrayList<>();
        this.shoppingList.addAll(cart.getShoppingProductList().stream().map(ShoppingProductResponse::new).collect(Collectors.toList()));
        this.payed = cart.isPayed();
    }
}


