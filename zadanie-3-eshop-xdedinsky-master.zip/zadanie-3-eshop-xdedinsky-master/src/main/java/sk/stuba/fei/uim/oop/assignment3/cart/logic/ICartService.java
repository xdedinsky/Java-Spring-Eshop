package sk.stuba.fei.uim.oop.assignment3.cart.logic;

import org.springframework.stereotype.Repository;
import sk.stuba.fei.uim.oop.assignment3.cart.web.bodies.ShoppingProductRequest;
import sk.stuba.fei.uim.oop.assignment3.cart.data.Cart;
import sk.stuba.fei.uim.oop.assignment3.exception.NotFoundException;
import sk.stuba.fei.uim.oop.assignment3.exception.IllegalOperationException;

@Repository
public interface ICartService {
    Cart createCart();
    Cart getCart(Long id) throws NotFoundException;
    void deleteCart(Long id) throws NotFoundException;
    Cart addProductToCart(Long CartId, ShoppingProductRequest request) throws NotFoundException, IllegalOperationException;
    double pay(Long id) throws NotFoundException, IllegalOperationException;
}
