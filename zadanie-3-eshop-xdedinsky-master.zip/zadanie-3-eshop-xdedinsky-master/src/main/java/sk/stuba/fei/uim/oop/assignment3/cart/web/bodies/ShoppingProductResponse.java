package sk.stuba.fei.uim.oop.assignment3.cart.web.bodies;


import lombok.Getter;
import sk.stuba.fei.uim.oop.assignment3.cart.data.ShoppingProduct;

@Getter
public class ShoppingProductResponse {
    private final Long productId;
    private final long amount;

    public ShoppingProductResponse(ShoppingProduct product) {
        this.productId = product.getProduct().getId();
        this.amount = product.getAmount();
    }
}
