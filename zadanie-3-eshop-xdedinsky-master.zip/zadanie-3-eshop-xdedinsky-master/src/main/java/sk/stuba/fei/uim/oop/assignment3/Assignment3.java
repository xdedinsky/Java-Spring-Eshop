package sk.stuba.fei.uim.oop.assignment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment3 {

    public static void main(String[] args) {
        SpringApplication.run(Assignment3.class, args);
    }

}
