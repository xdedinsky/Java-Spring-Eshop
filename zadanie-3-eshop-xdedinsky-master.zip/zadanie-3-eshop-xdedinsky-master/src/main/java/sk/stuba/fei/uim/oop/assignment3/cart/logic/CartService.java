package sk.stuba.fei.uim.oop.assignment3.cart.logic;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import sk.stuba.fei.uim.oop.assignment3.cart.data.Cart;
import sk.stuba.fei.uim.oop.assignment3.cart.data.ICartRepository;
import sk.stuba.fei.uim.oop.assignment3.cart.data.IShoppingProduct;
import sk.stuba.fei.uim.oop.assignment3.cart.data.ShoppingProduct;
import sk.stuba.fei.uim.oop.assignment3.cart.web.bodies.ShoppingProductRequest;
import sk.stuba.fei.uim.oop.assignment3.product.data.Product;
import sk.stuba.fei.uim.oop.assignment3.product.logic.IProductService;
import sk.stuba.fei.uim.oop.assignment3.exception.NotFoundException;
import sk.stuba.fei.uim.oop.assignment3.exception.IllegalOperationException;

@Service
public class CartService implements ICartService {
    @Autowired
    private ICartRepository ICartRepository;
    @Autowired
    private IShoppingProduct IShoppingProduct;
    @Autowired
    private IProductService productService;

    @Override
    public Cart createCart() {
        Cart cart = new Cart();
        cart.setPayed(false);
        return this.ICartRepository.save(cart);
    }

    @Override
    public Cart getCart(Long id) throws NotFoundException{
        return this.ICartRepository.findById(id).orElseThrow(NotFoundException::new);
    }

    @Override
    public void deleteCart(Long id) throws NotFoundException{
        Cart cart = this.ICartRepository.findById(id).orElseThrow(NotFoundException::new);
        this.ICartRepository.delete(cart);
    }

    @Override
    public Cart addProductToCart(Long cartId, ShoppingProductRequest request) throws NotFoundException, IllegalOperationException {
        Cart cart = ICartRepository.findById(cartId).orElseThrow(NotFoundException::new);
        Product product = productService.findById(request.getProductId());

        if (cart.isPayed()) {
            throw new IllegalOperationException();
        }

        if (request.getAmount() > product.getAmount()) {
            throw new IllegalOperationException();
        }

        boolean productAlreadyInCart = false;
        ShoppingProduct productTmp;
        for (int i = 0; i < cart.getShoppingProductList().size(); i++) {
            productTmp = cart.getShoppingProductList().get(i);
            if (productTmp.getProduct().getId().equals(request.getProductId())) {
                productTmp.setAmount(productTmp.getAmount() + request.getAmount());
                product.setAmount(product.getAmount() - request.getAmount());
                IShoppingProduct.save(productTmp);
                productAlreadyInCart = true;
                break;
            }
        }

        if (!productAlreadyInCart) {
            ShoppingProduct shoppingProduct = new ShoppingProduct(product, request.getAmount());
            product.setAmount(product.getAmount() - request.getAmount());
            IShoppingProduct.save(shoppingProduct);
            cart.getShoppingProductList().add(shoppingProduct);
        }

        return ICartRepository.save(cart);
    }

    @Override
    public double pay(Long id) throws NotFoundException, IllegalOperationException {
        Cart cart = this.ICartRepository.findById(id).orElseThrow(NotFoundException::new);
        if (cart.isPayed()) {
            throw new IllegalOperationException();
        }
        else {
            double totalPrice = 0;
            ShoppingProduct shoppingProduct;
            for (int i = 0; i < cart.getShoppingProductList().size(); i++) {
                shoppingProduct = cart.getShoppingProductList().get(i);
                totalPrice = totalPrice + productService.findById(shoppingProduct.getId()).getPrice() * shoppingProduct.getAmount();
            }
            cart.setPayed(true);
            this.ICartRepository.save(cart);
            return totalPrice;
        }
    }
}
